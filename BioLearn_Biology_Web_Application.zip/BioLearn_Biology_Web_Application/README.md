# BioLearn — Biology Learning Web Application

## Project overview
BioLearn is a responsive educational website that introduces basic biology concepts through topic cards, short explanations, searchable topics and an interactive quiz.

## Features
- Four learning topics: Cell Biology, Human Body, Plant Biology and Ecosystems
- Topic search
- Expandable topic explanations and key facts
- Three-question interactive quiz with score and feedback
- Responsive layout for desktop and mobile browsers

## Technologies used
- HTML5 — page structure
- CSS3 — styling and responsive layout
- JavaScript — search, topic details and quiz interactions

## How to run
1. Extract the ZIP file.
2. Open the `index.html` file in a web browser.
3. Select a topic, search for a topic, or complete the quiz.

No installation, server or database is required. An internet connection is only needed to load the optional Google Fonts; the application itself works offline.

## Project objective
The objective is to make introductory biology concepts easier to access and revise using a simple, interactive web application.

## Possible future improvements
- Add more biology topics and diagrams
- Add user accounts and progress tracking
- Store quiz scores in a database
- Add Telugu and other language support

## Academic honesty
This is a starter project template. Review the code, test it, and customize the content and design before submitting it. Be prepared to explain the features and your own contribution.
