const topicInfo = {
  cell: {
    title: 'Cell Biology',
    text: 'Cells are the smallest structural and functional units of living organisms. Some organisms consist of one cell, while others contain trillions of cells.',
    facts: ['The cell membrane controls what enters and leaves a cell.', 'The nucleus stores most of the cell’s genetic material.', 'Mitochondria release usable energy for many cell activities.']
  },
  body: {
    title: 'The Human Body',
    text: 'The human body is made of organ systems that work together. Each system has specific jobs that help maintain life and health.',
    facts: ['The heart pumps blood around the body.', 'The lungs exchange oxygen and carbon dioxide.', 'The digestive system breaks food into nutrients.']
  },
  plants: {
    title: 'Plant Biology',
    text: 'Plants are living organisms that usually make their own food through photosynthesis, using light energy, water and carbon dioxide.',
    facts: ['Roots absorb water and minerals from the soil.', 'Leaves are major sites of photosynthesis.', 'The stem supports the plant and transports materials.']
  },
  ecosystem: {
    title: 'Ecosystems',
    text: 'An ecosystem includes living organisms and the non-living parts of their environment, interacting as a system.',
    facts: ['Producers, such as green plants, make food.', 'Consumers obtain energy by eating other organisms.', 'Decomposers recycle nutrients back into the environment.']
  }
};

document.querySelectorAll('.learn-btn').forEach(button => {
  button.addEventListener('click', () => {
    const info = topicInfo[button.dataset.topic];
    document.getElementById('detailTitle').textContent = info.title;
    document.getElementById('detailText').textContent = info.text;
    const list = document.getElementById('detailFacts');
    list.replaceChildren();
    info.facts.forEach(fact => {
      const li = document.createElement('li');
      li.textContent = fact;
      list.appendChild(li);
    });
    document.getElementById('topicDetails').hidden = false;
    document.getElementById('topicDetails').scrollIntoView({behavior:'smooth', block:'nearest'});
  });
});

document.getElementById('closeDetails').addEventListener('click', () => {
  document.getElementById('topicDetails').hidden = true;
});

document.getElementById('topicSearch').addEventListener('input', event => {
  const query = event.target.value.trim().toLowerCase();
  let visible = 0;
  document.querySelectorAll('.topic-card').forEach(card => {
    const match = card.dataset.search.includes(query) || card.textContent.toLowerCase().includes(query);
    card.hidden = !match;
    if (match) visible++;
  });
  document.getElementById('noTopics').hidden = visible !== 0;
});

const questions = [
  {q:'What is the basic structural unit of life?', options:['Tissue','Cell','Organ','Organ system'], answer:1, explain:'A cell is the basic structural and functional unit of life.'},
  {q:'Which part of a plant mainly absorbs water from the soil?', options:['Flower','Leaf','Root','Fruit'], answer:2, explain:'Roots absorb water and minerals from the soil.'},
  {q:'Which organ pumps blood around the human body?', options:['Lungs','Brain','Stomach','Heart'], answer:3, explain:'The heart pumps blood through the circulatory system.'}
];
let current = 0, score = 0, answered = false;
const questionText = document.getElementById('questionText');
const optionsBox = document.getElementById('answerOptions');
const feedback = document.getElementById('quizFeedback');
const nextButton = document.getElementById('nextQuestion');

function showQuestion() {
  answered = false;
  const item = questions[current];
  document.getElementById('questionCount').textContent = `Question ${current+1} of ${questions.length}`;
  document.getElementById('scoreLabel').textContent = `Score: ${score}`;
  questionText.textContent = item.q;
  feedback.textContent = '';
  optionsBox.replaceChildren();
  item.options.forEach((option, index) => {
    const button = document.createElement('button');
    button.className = 'answer';
    button.textContent = option;
    button.addEventListener('click', () => chooseAnswer(index));
    optionsBox.appendChild(button);
  });
  nextButton.disabled = true;
  nextButton.textContent = current === questions.length-1 ? 'See result →' : 'Next question →';
}

function chooseAnswer(index) {
  if (answered) return;
  answered = true;
  const item = questions[current];
  [...optionsBox.children].forEach((button, i) => {
    button.disabled = true;
    if (i === item.answer) button.classList.add('correct');
    else if (i === index) button.classList.add('wrong');
  });
  if (index === item.answer) {
    score++;
    feedback.textContent = `Correct! ${item.explain}`;
  } else {
    feedback.textContent = `Not quite. ${item.explain}`;
  }
  document.getElementById('scoreLabel').textContent = `Score: ${score}`;
  nextButton.disabled = false;
}

nextButton.addEventListener('click', () => {
  if (!answered) return;
  current++;
  if (current < questions.length) {
    showQuestion();
  } else {
    questionText.textContent = `You scored ${score} out of ${questions.length}!`;
    optionsBox.replaceChildren();
    feedback.textContent = score === 3 ? 'Excellent work!' : 'Good effort. Review the topics and try again.';
    nextButton.textContent = 'Try again ↻';
    nextButton.disabled = false;
    nextButton.onclick = () => {
      current = 0; score = 0;
      nextButton.onclick = null;
      showQuestion();
    };
  }
});

showQuestion();
